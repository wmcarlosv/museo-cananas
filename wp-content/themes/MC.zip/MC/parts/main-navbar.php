<div class="nav-container">
  <img src="images/Logo-rojo.svg" loading="lazy" height="" width="150" alt="" class="main-logo mobile">
            <div data-w-id="20c92c8a-de61-cf16-b65e-7a6aa147bdad" class="menu-icon-wrapper">
                <div data-w-id="dcc06091-b988-2c01-f5b4-b8e9dc9c6251" data-animation-type="lottie" data-src="documents/4370-menu-button-190218a.json" data-loop="0" data-direction="1" data-autoplay="0" data-is-ix2-target="1" data-renderer="svg" data-default-duration="0.5333333333333333" data-duration="0"></div>
            </div>
            <div class="nav-content-wrapper">

                <a href="index.html" aria-current="page" class="w-inline-block w--current" cms-site-link="home"><img src="images/Logo-rojo.svg" loading="lazy" height="" width="150" alt="" class="main-logo"></a>
                <div class="nav-items-wrapper">
                  <div class="main-nav nav-link dropdown-wrapper w-dropdown">
                      <ul id="menu-navbar" class="menu" cms-menu="primary">
                          <li id="menu-item-610" class="nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-609 current_page_item menu-item-610">
                              <a href="" class="nav-link">Home</a>
                          </li>
                          <li id="menu-item-615" class=" nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-615 ">
                              <a href="" class="nav-link">Services</a>
                              <ul class=" sub-menu">
                                  <li id="menu-item-618" class=" nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-618">
                                      <a href="" class="nav-link">individuals</a>
                                  </li>
                                  <li id="menu-item-617" class="nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-617">
                                      <a href="" class="nav-link">roups</a>
                                  </li>
                                  <li id="menu-item-619" class="nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-619">
                                      <a href="" class="nav-link">interviews</a>
                                  </li>
                              </ul>
                          </li>
                          <li id="menu-item-30780" class="nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-30780">
                              <a href="" class="nav-link">My Book</a>
                          </li>
                          <li id="menu-item-614" class="nav-link menu-item menu-item-type-post_type menu-item-object-page menu-item-614">
                              <a href="" class="nav-link">Clients</a>
                          </li>
                      </ul>
                  </div>
                </div>

                <!-- #main-nav -->
                <div class="nav-items-wrapper-language">
                    <a href="#" class="lenguage-links selected">Es</a>
                    <div class="text-block">/</div>
                    <a href="#" class="lenguage-links">En</a>
                </div>
            </div>
        </div>
